steps:

- pip install -r requirements.txt

- edit the 2 paths in the code.

- python3 main.py


* All images must be in the same folder as the main.py 
